from flask import Flask, render_template, request, redirect, url_for, session
app=Flask(__name__)
app.secret_key='sravanthi'

@app.route('/')
def home():
    if 'username' in session:
        return 'User Dashboard'
    return redirect(url_for('login'))
users={
    'sravanthi':'sravanthi123'
}
@app.route('/login', methods=['POST','GET'])

def login():
    if request.method == 'POST':
        username = request.form.get('uname')
        userpassword = request.form.get('upassword')
        
        if username in users:
            if userpassword == users[username]:
                session.permanent = True
                session['username'] = username
            return "Successfully Logged In"
        else:
            return "Wrong Password."

    return '''
              <form method='POST'action='/login'>
              <lable for='name'>Name</lable>
              <input type='text' id='name'name='uname'>
              <br>
              <lable for='password'>Password</lable>
              <input type='password' id='password'name='upassword'>
              <br>
              <br>
              <input type='submit'value='Login'>
            
              </form>'''
@app.route('/cart')
def cart():
    if 'username' in session:
        return f'{session["username"]} cart'
    else:
        return redirect(url_for('login'))
@app.route('/logout')
def logout():
    if 'username' in session:
        session.pop('username')
        return 'Logged Out Successfully'
    return redirect(url_for('login'))
app.run(debug=True,port=5000)